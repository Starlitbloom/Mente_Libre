package com.mentelibre.emotion_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmotionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
